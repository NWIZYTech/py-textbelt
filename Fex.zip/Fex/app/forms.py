from flask_wtf import FlaskForm

from wtforms import StringField, IntegerField, SubmitField, PasswordField

from wtforms.validators import ValidationError, DataRequired, Email

#To validate user before Registering
from app.models import user
from app import db

class SubForm(FlaskForm):
	Email=StringField("Email address", validators=[DataRequired(),Email()])
	Phone=IntegerField("Telephone",validators=[DataRequired()])
	name=PasswordField("What time is it")
	
	submit=SubmitField("Touch me")
	
	def validate_username(self,Email,Phone):
		'''Validating user frim database'''
		user=user.query.filter_by(Email=Email.data, Telephone=phone.data).first()
		if user is not None:
			raise ValidationError("Please use a different Email address")
		
		