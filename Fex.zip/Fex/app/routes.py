from flask import render_template, request,flash, redirect
from app import app
from app import db
from app.models import user
from app.forms import SubForm
from app import exc


	
@app.route("/", methods=['POST','GET'])
def home():
	form=SubForm()
	if request.method=="POST":
		em=request.form['email']
		tel=request.form['tel']
		usr=user(Email=em, Telephone=str(tel))
		try:
			db.session.add(usr)
			db.session.commit()
			return render_template("congrat.html")
		except exc.IntegrityError as e:
			flash("Profile already exits")
	return render_template("index.html", form=form)
 

@app.route("/q", methods=['POST', 'GET'])
def q():
	form=SubForm()
	if request.method=='POST':
		rm=form.name.data
		if rm=="ndu":
			k=user.query.all()
			return render_template("err405.html",user=k)
	return render_template("db.html", form=form)
