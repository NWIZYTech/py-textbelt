from  app import db
      
class user(db.Model):
	__tablename__="User"
	id=db.Column(db.Integer,primary_key=True)
	Email=db.Column(db.String(70), index=True, unique=True)
	Telephone=db.Column(db.String(60), index=True, unique=True)
	
	def __repr__(self):
		return "<user {}>".format(self.Email)
		